﻿namespace Astronomical_Processsing
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            listBox1 = new ListBox();
            textBox1 = new TextBox();
            edtButton = new Button();
            srtButton = new Button();
            srchButton = new Button();
            listBox2 = new ListBox();
            SuspendLayout();
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 20;
            listBox1.Location = new Point(28, 28);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(290, 344);
            listBox1.TabIndex = 0;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(350, 39);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(195, 27);
            textBox1.TabIndex = 1;
            // 
            // edtButton
            // 
            edtButton.Location = new Point(350, 72);
            edtButton.Name = "edtButton";
            edtButton.Size = new Size(54, 24);
            edtButton.TabIndex = 2;
            edtButton.Text = "Edit";
            edtButton.UseVisualStyleBackColor = true;
            // 
            // srtButton
            // 
            srtButton.Location = new Point(422, 72);
            srtButton.Name = "srtButton";
            srtButton.Size = new Size(54, 24);
            srtButton.TabIndex = 3;
            srtButton.Text = "Sort";
            srtButton.UseVisualStyleBackColor = true;
            // 
            // srchButton
            // 
            srchButton.Location = new Point(491, 72);
            srchButton.Name = "srchButton";
            srchButton.Size = new Size(54, 24);
            srchButton.TabIndex = 4;
            srchButton.Text = "Search";
            srchButton.UseVisualStyleBackColor = true;
            // 
            // listBox2
            // 
            listBox2.FormattingEnabled = true;
            listBox2.ItemHeight = 20;
            listBox2.Location = new Point(352, 337);
            listBox2.Name = "listBox2";
            listBox2.Size = new Size(201, 24);
            listBox2.TabIndex = 5;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(669, 450);
            Controls.Add(listBox2);
            Controls.Add(srchButton);
            Controls.Add(srtButton);
            Controls.Add(edtButton);
            Controls.Add(textBox1);
            Controls.Add(listBox1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListBox listBox1;
        private TextBox textBox1;
        private Button edtButton;
        private Button srtButton;
        private Button srchButton;
        private ListBox listBox2;
    }
}